from flask import Flask
from data import db_session
from data.users import User

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/mars_explorer.db")
    user = User()
    db_sess = db_session.create_session()
    user.surname = "Scott"
    user.name = "Ridley"
    user.age = 21
    user.position = 'captain'
    user.speciality = 'research engineer'
    user.address = 'module_1'
    user.email = 'scott_chief@mars.org'
    db_sess.add(user)
    db_sess.commit()

    user = User()
    user.surname = "Yohansen"
    user.name = "Bet"
    user.age = 24
    user.position = 'programmer'
    user.speciality = 'programming'
    user.address = 'module_4'
    user.email = 'youhansen_bet@mars.org'
    db_sess.add(user)
    db_sess.commit()

    user = User()
    user.surname = "Uotni"
    user.name = 'Mark'
    user.age = 24
    user.position = 'doctor'
    user.speciality = 'healing'
    user.address = 'module_2'
    user.email = 'mark_uotni@mars.org'
    db_sess.add(user)
    db_sess.commit()

    user = User()
    user.surname = "Rick"
    user.name = "Martiness"
    user.age = 29
    user.position = 'pilot'
    user.speciality = 'flying'
    user.address = 'module_3'
    user.email = 'rick_mart@mars.org'

    db_sess.add(user)
    db_sess.commit()
    app.run()


if __name__ == '__main__':
    main()